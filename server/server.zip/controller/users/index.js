module.exports = {
  signin: require('./signin'),
  signup: require('./signup'),
  profile: require('./profile'),
};
