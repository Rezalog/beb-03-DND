module.exports = {
  usersController: require("./users"),
  contractsController: require("./contracts"),
};
